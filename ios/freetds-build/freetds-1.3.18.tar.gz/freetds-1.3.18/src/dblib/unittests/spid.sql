select @@SPID
go
